using Microsoft.Extensions.DependencyInjection;
using DirectScale.Disco.Extension;
using DirectScale.Disco.Extension.Hooks;
using DirectScale.Disco.Extension.Api;
//using DirectScale.Disco.Extension.Hooks.Orders;
//using DirectScale.Disco.Extension.Hooks.Commissions;
//using static TooComplicatedButThisIsTheOnlyWay;
//using static TooComplicatedButThisIsTheOnlyWayTest;
using bombshells.Hooks;
using DirectScale.Disco.Extension.Hooks.Associates.Enrollment;
using DirectScale.Disco.Extension.Hooks.Associates;
using DirectScale.Disco.Extension.Hooks.Commissions;
//using bombshells.Services;

namespace bombshells
{
    public class ExtensionEntry : IExtension
    {
        public void ConfigureServices(IServiceCollection services)
        {
            //NOTE: These are examples of how to implement a custom Api Endpoint and a custom hook.
            //services.AddSingleton<IExampleService, ExampleService>();
            //services.AddSingleton<IApiEndpoint, ApiExample>();
            //services.AddSingleton<IHook<IsEmailAvailableHookRequest, IsEmailAvailableHookResponse>, IsEmailAvailableHook>();
            services.AddSingleton<IApiEndpoint, LeaderBoardRecruitment>(); // 
            services.AddSingleton<IApiEndpoint, LeaderBoardEnrollment>(); // New Leaderboard with last updates ( with statement 'Personal Sales > 0 )
            services.AddSingleton<IApiEndpoint, LeaderBoardPersonalSales>(); // We don't use this leaderboard ( Personal sales Leaderboard )
            services.AddSingleton<IApiEndpoint, LeaderBoardEnrollmentWithIDs>(); // Old one which can be deleted
            services.AddSingleton<IApiEndpoint, LeaderBoardEnrollmentPersonalSales>(); // Test with new KPI ( NLEC )
            services.AddSingleton<IApiEndpoint, HighestRanksList>(); // CRM_CommissionAssociateValues HighRank
            services.AddSingleton<IApiEndpoint, CustomFieldAPI>(); // API to validate associates
            //services.AddSingleton<IApiEndpoint, MessageToMentorAPI>();
            //services.AddSingleton<IApiEndpoint, MessageToDownlinesAPI>();
            //services.AddSingleton<IApiEndpoint, MessageToTeamAPI>();
            //services.AddSingleton<IApiEndpoint, CurrencyAPI>();
            services.AddSingleton<IApiEndpoint, BiggerRankNotificationAPI>(); // BiggerRankNotification API
            services.AddSingleton<IApiEndpoint, NotificationAPI>(); // Notification API
            //services.AddSingleton<AccountCommissionMerchant, HyperWalletGBP>(); // HyperWalletGBP 9001
            //services.AddSingleton<AccountCommissionMerchant, HyperWalletAUD>(); // HyperWalletAUD 9002
            //services.AddSingleton<AccountCommissionMerchant, HyperWalletEUR>(); // HyperWalletEUR 9003
            //services.AddSingleton<IHook<WriteApplicationHookRequest, WriteApplicationHookResponse>, TestingDSSQLData>(); // Testing DS SQL data
            //services.AddSingleton<IHook<AdjustNewOrderPaymentsHookRequest, AdjustNewOrderPaymentsHookResponse>, SendGridHook3>(); // SendGridHook4
            //services.AddSingleton<IHook<LogRealtimeRankAdvanceHookRequest, LogRealtimeRankAdvanceHookResponse>, SendGridHook2>(); // SendGridHook4
            //services.AddSingleton<IHook<LogRealtimeRankAdvanceHookRequest, LogRealtimeRankAdvanceHookResponse>, SendGridHook2Test>(); // SendGridHook4
            //services.AddSingleton<IHook<WriteApplicationHookRequest, WriteApplicationHookResponse>, HyperWalletHook>(); // HyperWallet Hook to set new associates' merchant to relevant HyperWallet currency
            services.AddSingleton<IHook<WriteApplicationHookRequest, WriteApplicationHookResponse>, KlaviyoHook>(); // HyperWallet Hook to set new associates' merchant to relevant HyperWallet currency
            //services.AddSingleton<IHook<WriteApplicationHookRequest, WriteApplicationHookResponse>, TestingDailyRun>(); // Just for testing purposes
            //services.AddSingleton<IHook<GetAssociatesStatsHookRequest, GetAssociatesStatsHookResponse>, NewRankHook>(); // New Order Hook
        }
    }
}
