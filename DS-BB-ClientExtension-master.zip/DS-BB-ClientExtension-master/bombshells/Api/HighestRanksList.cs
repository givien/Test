using Dapper;
using System.Data.SqlClient;
using DirectScale.Disco.Extension.Api;
using DirectScale.Disco.Extension.Services;
using System.Linq;
using DirectScale.Disco.Extension;

public class HighestRanksList : IApiEndpoint
{
    private readonly IDataService _dataService;
    public HighestRanksList(IDataService dataService)
    {
        _dataService = dataService;
    }
    public ApiDefinition GetDefinition()
    {
        return new ApiDefinition
        {
            Route = "bombshells/HighestRanksList",
            RequireAuthentication = false
        };
    }
    public IApiResponse Post(ApiRequest request)
    {
        using (var db = new SqlConnection(_dataService.ConnectionString.ConnectionString))
        {
            string sql = $"select AssociateID, HighRank from CRM_CommissionAssociateValues where ComPeriodID = month(GETDATE()) + 18";
            
            return new Ok(new { Status = 1, RequestMessage = db.Query<Columns>(sql).ToList() });
        }
    }
    public class Columns
    {
    public int AssociateID { get; set; }
    public int HighRank { get; set; }
    }
}