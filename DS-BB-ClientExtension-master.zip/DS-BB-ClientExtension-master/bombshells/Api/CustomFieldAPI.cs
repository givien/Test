using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using bombshells;
using Dapper;
using DirectScale.Disco.Extension.Api;
using DirectScale.Disco.Extension.Services;
using Newtonsoft.Json.Linq;
using SendGrid;
using SendGrid.Helpers.Mail;

public class CustomFieldAPI : IApiEndpoint
{
    private readonly IDataService _dataService;
    private readonly IAssociateService _associateService;
    public CustomFieldAPI(IAssociateService associateService, IDataService dataService)
    {
        _dataService = dataService;
        _associateService = associateService;
    }
    public ApiDefinition GetDefinition()
    {
        return new ApiDefinition
        {
            Route = "bombshells/CustomFieldAPI",
            RequireAuthentication = false
        };
    }
    public IApiResponse Post(ApiRequest request)
    {
        using (var db = new SqlConnection(_dataService.ConnectionString.ConnectionString))
        {
            int associateID = 0;
            try
            {
                string x = "";
                request.QueryParams.TryGetValue("QueryParams", out x);
                string distributorsQuery = $"SELECT recordnumber FROM CRM_Distributors where recordnumber >= " + x;
                var distributorsList = db.Query<Distributor>(distributorsQuery).ToList();
                if (distributorsList.Count < 1)
                {
                    return new Ok(new { Status = 1, RequestMessage = "There is not any useful row in CRM_Distributors" });
                }
                foreach (var user in distributorsList)
                {
                    var associate = _associateService.GetAssociate(user.recordnumber);
                    associateID = associate.AssociateId;
                    associate.Custom.Field1 = "validated";
                    _associateService.UpdateAssociate(associate);
                }
            }
            catch (Exception e)
            {
                return new Ok(new { Status = 1, RequestMessage = associateID + "__" + e.ToString()});
            }
            return new Ok(new { Status = 1, RequestMessage = "Completed. - " + associateID });
        }

    }
    public class Distributor
    {
        public int recordnumber { get; set; }
    }
}
