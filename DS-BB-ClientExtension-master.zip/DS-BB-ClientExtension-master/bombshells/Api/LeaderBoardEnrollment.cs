using Dapper;
using System.Collections.Generic;
using System.Data.SqlClient;
using DirectScale.Disco.Extension.Api;
using DirectScale.Disco.Extension.Services;
using System.Linq;
using System;

public class LeaderBoardEnrollment : IApiEndpoint
{
    private readonly IAssociateService _associateService;
    private readonly IRequestParsingService _requestParsing;
    private readonly DirectScale.Disco.Extension.Services.IDataService _dataService;
    public LeaderBoardEnrollment(IAssociateService associateService, IDataService dataService, IRequestParsingService requestParsing)
    {
        _associateService = associateService;
        _requestParsing = requestParsing;
        _dataService = dataService;
    }
    public ApiDefinition GetDefinition()
    {
        return new ApiDefinition
        {
            Route = "bombshells/LeaderBoardEnrollment",
            RequireAuthentication = false
        };
    }
    public IApiResponse Post(ApiRequest request)
    {
        using (var dbConnection = new System.Data.SqlClient.SqlConnection(_dataService.ConnectionString.ConnectionString))
        {
            var currentMonthNumber = Convert.ToInt32(DateTime.Now.Month.ToString("00"));
            string sql = $"select top 10 b.DisplayName as FullName, a.Value as Volume, a.AssociateID as ID from CRM_Stats_StatValues a join Users b on b.BackOfficeId = a.AssociateID where a.PeriodKey = 'MonthlyBBJan_" + currentMonthNumber + "/1/2021' and a.Stat = 'NLEC' and b.BackOfficeId > 74 order by a.Value desc";

            return new Ok(new { Status = 1, RequestMessage = dbConnection.Query<EnrollmentGet>(sql).ToList() });
        }
    }
    public class EnrollmentGet
    {
        public string FullName { get; set; }
        public int Volume { get; set; }
        public int ID { get; set; }
    }
}
