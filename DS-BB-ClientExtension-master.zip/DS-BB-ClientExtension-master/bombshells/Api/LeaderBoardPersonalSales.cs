using Dapper;
using System.Data.SqlClient;
using DirectScale.Disco.Extension.Api;
using DirectScale.Disco.Extension.Services;
using System.Linq;

public class LeaderBoardPersonalSales : IApiEndpoint
{
    private readonly IAssociateService _associateService;
    private readonly IRequestParsingService _requestParsing;
    private readonly IDataService _dataService;
    public LeaderBoardPersonalSales(IAssociateService associateService, IDataService dataService, IRequestParsingService requestParsing)
    {
        _associateService = associateService;
        _requestParsing = requestParsing;
        _dataService = dataService;
    }
    public ApiDefinition GetDefinition()
    {
        return new ApiDefinition
        {
            Route = "bombshells/LeaderBoardPersonalSales",
            RequireAuthentication = false
        };
    }
    public IApiResponse Post(ApiRequest request)
    {
        using (var ConnectionToPersonalSales = new SqlConnection(_dataService.ConnectionString.ConnectionString))  //used to connect to the clients database.
        {
            string sqlRequestForPS = $"select top 20 b.DisplayName FullName, a.CV Volume from CRM_Stats a join Users b on b.BackOfficeId = a.AssociateID where a.PeriodKey = 'MonthlyBB_12/1/2020' and b.BackOfficeId > 74 order by a.CV desc";
            
            return new Ok(new { Status = 1, RequestMessage = ConnectionToPersonalSales.Query<QuerryResultPersonalSales>(sqlRequestForPS).ToList() });
        }
    }
    public class QuerryResultPersonalSales
    {
    public string FullName { get; set; }
    public int Volume { get; set; }
    }
}
