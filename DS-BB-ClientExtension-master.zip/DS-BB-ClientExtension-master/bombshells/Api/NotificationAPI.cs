using System;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using bombshells;
using Dapper;
using DirectScale.Disco.Extension.Api;
using DirectScale.Disco.Extension.Services;
using SendGrid;
using SendGrid.Helpers.Mail;

public class NotificationAPI : IApiEndpoint
{
    private readonly IDataService _dataService;
    private readonly IAssociateService _associateService;
    public NotificationAPI(IAssociateService associateService, IDataService dataService)
    {
        _dataService = dataService;
        _associateService = associateService;
    }
    public ApiDefinition GetDefinition()
    {
        return new ApiDefinition
        {
            Route = "bombshells/NotificationAPI",
            RequireAuthentication = false
        };
    }
    public IApiResponse Post(ApiRequest request)
    {
        using (var db = new SqlConnection(_dataService.ConnectionString.ConnectionString))
        {
            int associateID = 0;
            var currentMonthNumber = Convert.ToInt32(DateTime.Now.Month.ToString("00"));
            // Getting ranks from CRM_Stats with current month's period key and changed 3 days before at the latest
            string statsQuery = $"SELECT recordnumber, last_modified, AssociateID, Rank, PeriodKey FROM CRM_Stats WHERE last_modified > dateadd(day, -2, getdate()) AND PeriodKey = 'MonthlyBBJan_" + currentMonthNumber + "/1/2021' AND Rank > 20 ORDER BY Rank; ";
            var statsList = db.Query<Stat>(statsQuery).ToList();
            if (statsList.Count < 1)
            {
                return new Ok(new { Status = 1, RequestMessage = "No results for this month" });
            }
            // Getting last month's highest rank from CRM_CommissionAssociateValues with last month's period ID
            string crmAVQuery = $"SELECT AssociateID, HighRank FROM CRM_CommissionAssociateValues WHERE ComPeriodID = " + (18 + currentMonthNumber) + ";";
            var crmAVList = db.Query<CrmAV>(crmAVQuery).ToList();
            if (crmAVList.Count < 1)
            {
                return new Ok(new { Status = 1, RequestMessage = "No results for last month" });
            }
            // Getting Custom Field 1 values to compare and update if needed
            string customFliedsQuery = $"SELECT AssociateID,Field1 FROM CRM_CustomFields;";
            var customFliedsList = db.Query<CustomField>(customFliedsQuery).ToList();
            if (customFliedsList.Count < 1)
            {
                return new Ok(new { Status = 1, RequestMessage = "Please, inform tech" });
            }
            // Creating table pattern which will send via e-mail
            string content = "<table style='width:100%;font-size: 18px;'><thead><tr><th style='border: 1px solid;'>#</th><th style='border: 1px solid;'>Full name</th><th style='border: 1px solid;'>E-mail</th>" +
                        "<th style='border: 1px solid;'>Rank</th></tr></thead><tbody style='text-align: center;'>";
            // Variable to count the rows of table
            int rowCount = 1;
            // I am using this to find the exception if occurs
            try
            {
                // Loop to compare all rows in the Stats list
                foreach (var stat in statsList)
                {
                    // Default Custom Field 1 value
                    string fieldValue = "1,0,0,0,0,0,0,0,0,0,0,0,0,0";
                    // Minimal Rank value to send via mail
                    string rank = "2 Star";
                    if (stat.Rank > 20)
                    {
                        fieldValue = "1,1,1,1,0,0,0,0,0,0,0,0,0,0";
                    }
                    if (stat.Rank > 30)
                    {
                        fieldValue = "1,1,1,1,1,0,0,0,0,0,0,0,0,0";
                        rank = "3 Star";
                    }
                    if (stat.Rank > 40)
                    {
                        fieldValue = "1,1,1,1,1,1,0,0,0,0,0,0,0,0";
                        rank = "4 Star";
                    }
                    if (stat.Rank > 50)
                    {
                        fieldValue = "1,1,1,1,1,1,1,0,0,0,0,0,0,0";
                        rank = "5 Star";
                    }
                    if (stat.Rank > 60)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,0,0,0,0,0,0";
                        rank = "6 Star";
                    }
                    if (stat.Rank > 70)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,1,0,0,0,0,0";
                        rank = "7 Star";
                    }
                    if (stat.Rank > 80)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,1,1,0,0,0,0";
                        rank = "8 Star";
                    }
                    if (stat.Rank > 90)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,1,1,1,0,0,0";
                        rank = "9 Star";
                    }
                    if (stat.Rank > 100)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,1,1,1,1,0,0";
                        rank = "10 Star";
                    }
                    if (stat.Rank > 110)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,1,1,1,1,1,0";
                        rank = "11 Star";
                    }
                    if (stat.Rank > 120)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,1,1,1,1,1,1";
                        rank = "12 Star";
                    }
                    //Commission Associate Value. Finding with Associate ID
                    CrmAV crmAV = crmAVList.FirstOrDefault(x => x.AssociateID == stat.AssociateID);
                    //Custom Field 1 value. Finding with Associate ID
                    CustomField cf = customFliedsList.FirstOrDefault(x => x.AssociateID == stat.AssociateID);
                    // In this case, Commission Associate Value exists. So, need to compare
                    if (crmAV != null)
                    {
                        // In this case, current Rank is greater than Last Month's Highest Rank
                        if (stat.Rank > crmAV.HighRank)
                        {
                            //In this case, Custom Field 1 value exists
                            if (cf != null)
                            {
                                // In this case, Custom Field 1 value is different.
                                if (cf.Field1 != fieldValue)
                                {
                                    // Getting the details of associate
                                    var associate = _associateService.GetAssociate(stat.AssociateID);
                                    string name = associate.DisplayFirstName.ToUpper() + " " + associate.DisplayLastName.ToUpper();
                                    string mail = associate.EmailAddress.ToLower();
                                    // Updating Custom Field 1 value
                                    associate.Custom.Field1 = fieldValue;
                                    _associateService.UpdateAssociate(associate);
                                    associateID = associate.AssociateId;
                                    // If the Current Rank is greater than 1 Star it needs to add to the table which will send via e-mail
                                    if (stat.Rank > 20)
                                    {
                                        // Adding a row to table
                                        content = content + "<tr style='height:50px'><td style='border: 1px solid;'>" + rowCount + "</td><td style='border: 1px solid;'>" + name + "</td><td style='border: 1px solid;'>" + mail + "</td><td style='border: 1px solid;'>" + rank + "</td></tr>";
                                        rowCount++;
                                    }
                                }
                            }
                            // In this case, Custom Field value does not exist.
                            else
                            {
                                //// Creating Custom Field 1 value
                                //string CreatecustomFliedQuery = $"INSERT INTO CRM_CustomFields(AssociateID, Field1) VALUES (" + stat.AssociateID + ", '" + fieldValue + "');";
                                //var customFliedsResult = db.Query<string>(CreatecustomFliedQuery).ToList();
                                //// If the Current Rank is greater than 1 Star it needs to add to the table which will send via e-mail
                                //if (stat.Rank > 20)
                                //{
                                //    // Getting the details of associate
                                //    var associate = _associateService.GetAssociate(stat.AssociateID);
                                //    string name = associate.DisplayFirstName.ToUpper() + " " + associate.DisplayLastName.ToUpper();
                                //    string mail = associate.EmailAddress.ToLower();
                                //    associate.Custom.Field1 = "test";
                                //    _associateService.UpdateAssociate(associate);
                                //    // Adding a row to table
                                //    content = content + "<tr style='height:50px'><td style='border: 1px solid;'>" + rowCount + "</td><td style='border: 1px solid;'>" + name + "</td><td style='border: 1px solid;'>" + mail + "</td><td style='border: 1px solid;'>" + rank + "</td></tr>";
                                //    rowCount++;
                                //}
                            }
                        }
                        // In this case, current Rank is smaller than Last Month's Highest Rank. Doesn't need to do anything
                        else
                        {

                        }
                    }
                    // In this case, there is not Last Month's Highest Rank. So, the current Rank is highest achieved rank
                    else
                    {
                        //In this case, Custom Field 1 value exists
                        if (cf != null)
                        {
                            // In this case, Custom Field 1 value is different.
                            if (cf.Field1 != fieldValue)
                            {
                                // Getting the details of associate
                                var associate = _associateService.GetAssociate(stat.AssociateID);
                                string name = associate.DisplayFirstName.ToUpper() + " " + associate.DisplayLastName.ToUpper();
                                string mail = associate.EmailAddress.ToLower();
                                // Updating Custom Field 1 value
                                associate.Custom.Field1 = fieldValue;
                                _associateService.UpdateAssociate(associate);
                                associateID = associate.AssociateId;
                                // If the Current Rank is greater than 1 Star it needs to add to the table which will send via e-mail
                                if (stat.Rank > 20)
                                {

                                    // Adding a row to table
                                    content = content + "<tr style='height:50px'><td style='border: 1px solid;'>" + rowCount + "</td><td style='border: 1px solid;'>" + name + "</td><td style='border: 1px solid;'>" + mail + "</td><td style='border: 1px solid;'>" + rank + "</td></tr>";
                                    rowCount++;
                                }
                            }
                        }
                        // In this case, Custom Field value does not exist.
                        else
                        {
                            //// Creating Custom Field 1 value
                            //string CreatecustomFliedQuery = $"INSERT INTO CRM_CustomFields(AssociateID, Field1) VALUES (" + stat.AssociateID + ", '" + fieldValue + "');";
                            //var customFliedsResult = db.Query<string>(CreatecustomFliedQuery).ToList();
                            //// If the Current Rank is greater than 1 Star it needs to add to the table which will send via e-mail
                            //if (stat.Rank > 20)
                            //{
                            //    // Getting the details of associate
                            //    var associate = _associateService.GetAssociate(stat.AssociateID);
                            //    string name = associate.DisplayFirstName.ToUpper() + " " + associate.DisplayLastName.ToUpper();
                            //    string mail = associate.EmailAddress.ToLower();
                            //    associate.Custom.Field1 = "test";
                            //    _associateService.UpdateAssociate(associate);
                            //    // Adding a row to table
                            //    content = content + "<tr style='height:50px'><td style='border: 1px solid;'>" + rowCount + "</td><td style='border: 1px solid;'>" + name + "</td><td style='border: 1px solid;'>" + mail + "</td><td style='border: 1px solid;'>" + rank + "</td></tr>";
                            //    rowCount++;
                            //}
                        }
                    }
                    // In this case, I am sending a mail for every 200 rows
                    if ((rowCount - 1) % 200 == 0 && content.Contains("<td"))
                    {
                        // Adding the last line of the table
                        content = content + "</tbody></table >";
                        // Task to send mail
                        async Task sendMaill()
                        {
                            // SendGrid API Key
                            var client = new SendGridClient("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");
                            // The email address which will send the mail
                            var from = new EmailAddress("no-reply@glowb.team", "Ruslan");
                            // The subject of mail
                            var subject = "Notification API";
                            // The email address which will receive the mail
                            var to = new EmailAddress("system-internal@glowb.team", "Example User");
                            // I am not using this parameter
                            var plainTextContent = "";
                            // The content of mail
                            var htmlContent = content;
                            // Sendgrid function to send the mail
                            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
                            // The response of the function
                            var response = await client.SendEmailAsync(msg);
                        }
                        // Helper to run the task
                        AsyncHelper.RunSync(sendMaill);
                        // Table pattern
                        content = "<table style='width:100%;font-size: 18px;'><thead><tr><th style='border: 1px solid;'>#</th><th style='border: 1px solid;'>Full name</th><th style='border: 1px solid;'>E-mail</th>" +
                                    "<th style='border: 1px solid;'>Rank</th></tr></thead><tbody style='text-align: center;'>";
                    }
                }
                //In this case, I am sending the rest rows of the table
                if (content.Contains("<td"))
                {
                    // Adding the last line of the table
                    content = content + "</tbody></table >";
                    // Task to send mail
                    async Task sendMail()
                    {
                        // SendGrid API Key
                        var client = new SendGridClient("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");
                        // The email address which will send the mail
                        var from = new EmailAddress("no-reply@glowb.team", "Ruslan");
                        // The subject of mail
                        var subject = "Notification API";
                        // The email address which will receive the mail
                        var to = new EmailAddress("system-internal@glowb.team", "Example User");
                        // I am not using this parameter
                        var plainTextContent = "";
                        // The content of mail
                        var htmlContent = content;
                        // Sendgrid function to send the mail
                        var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
                        // The response of the function
                        var response = await client.SendEmailAsync(msg);
                    }
                    // Helper to run the task
                    AsyncHelper.RunSync(sendMail);
                }
            }
            // In this case, exception occured
            catch (Exception e)
            {
                // I am showing the details of exception
                return new Ok(new { Status = 1, RequestMessage = associateID + "___" + e.ToString() });
            }
            // In this case, the operation completed successfully. It will show the row counts of the table in the result
            if (rowCount > 1)
            {
                return new Ok(new { Status = 1, RequestMessage = "The table should contain " + (rowCount - 1) + " row/s." });
            }
            else
            {
                return new Ok(new { Status = 1, RequestMessage = "No any news" });
            }
        }

    }
    // Class to list the CRM_Stats table
    public class Stat
    {
        public int recordnumber { get; set; }
        public DateTime last_modified { get; set; }
        public int AssociateID { get; set; }
        public int Rank { get; set; }
        public string PeriodKey { get; set; }
    }
    // Class to list the CRM_CommissionMerchantCommissionAssociateValues table
    public class CrmAV
    {
        public int AssociateID { get; set; }
        public int HighRank { get; set; }
    }
    // Class to list the CRM_CustomFields table
    public class CustomField
    {
        public int AssociateID { get; set; }
        public string Field1 { get; set; }
    }
}
