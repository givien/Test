using System;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using bombshells;
using Dapper;
using DirectScale.Disco.Extension.Api;
using DirectScale.Disco.Extension.Services;
using SendGrid;
using SendGrid.Helpers.Mail;

public class BiggerRankNotificationAPI : IApiEndpoint
{
    private readonly IDataService _dataService;
    private readonly IAssociateService _associateService;
    public BiggerRankNotificationAPI(IAssociateService associateService, IDataService dataService)
    {
        _dataService = dataService;
        _associateService = associateService;
    }
    public ApiDefinition GetDefinition()
    {
        return new ApiDefinition
        {
            Route = "bombshells/BiggerRankNotificationAPI",
            RequireAuthentication = false
        };
    }
    public IApiResponse Post(ApiRequest request)
    {
        using (var db = new SqlConnection(_dataService.ConnectionString.ConnectionString))
        {
            int associateID = 0;
            var currentMonthNumber = Convert.ToInt32(DateTime.Now.Month.ToString("00"));
            // Getting ranks from CRM_Stats with last month's period key and changed 3 days before at the latest
            string statsQuery = $"SELECT recordnumber, last_modified, AssociateID, Rank, PeriodKey FROM CRM_Stats WHERE last_modified > dateadd(day, -2, getdate()) AND PeriodKey = 'MonthlyBBJan_" + currentMonthNumber + "/1/2021' AND Rank > 80 ORDER BY Rank; ";
            var statsList = db.Query<Stat>(statsQuery).ToList();
            if (statsList.Count < 1)
            {
                return new Ok(new { Status = 1, RequestMessage = "No results for this month" });
            }
            // Getting Custom Field 2 values to compare and update if needed
            string customFliedsQuery = $"SELECT AssociateID,Field2 FROM CRM_CustomFields;";
            var customFliedsList = db.Query<CustomField>(customFliedsQuery).ToList();
            if (customFliedsList.Count < 1)
            {
                return new Ok(new { Status = 1, RequestMessage = "Please, inform tech" });
            }
            // Creating table pattern which will send via e-mail
            string content = "<table style='width:100%;font-size: 18px;'><thead><tr><th style='border: 1px solid;'>#</th><th style='border: 1px solid;'>Full name</th><th style='border: 1px solid;'>E-mail</th>" +
                        "<th style='border: 1px solid;'>Rank</th></tr></thead><tbody style='text-align: center;'>";
            // Variable to count the rows of table
            int rowCount = 1;
            // I am using this to find the exception if occurs
            try
            {
                // Loop to compare all rows in the Stats list
                foreach (var stat in statsList)
                {
                    // Default Custom Field 2 value
                    string fieldValue = "1,0,0,0,0,0,0,0,0,0,0,0,0,0";
                    // Minimal Rank value to send via mail
                    string rank = "8 Star";
                    if (stat.Rank > 80)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,1,1,0,0,0,0";
                    }
                    if (stat.Rank > 90)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,1,1,1,0,0,0";
                        rank = "9 Star";
                    }
                    if (stat.Rank > 100)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,1,1,1,1,0,0";
                        rank = "10 Star";
                    }
                    if (stat.Rank > 110)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,1,1,1,1,1,0";
                        rank = "11 Star";
                    }
                    if (stat.Rank > 120)
                    {
                        fieldValue = "1,1,1,1,1,1,1,1,1,1,1,1,1,1";
                        rank = "12 Star";
                    }
                    //Custom Field 2 value. Finding with Associate ID
                    CustomField cf = customFliedsList.FirstOrDefault(x => x.AssociateID == stat.AssociateID);
                    //In this case, Custom Field 2 value exists
                    if (cf != null)
                    {
                        // In this case, Custom Field 2 value is different.
                        if (cf.Field2 != fieldValue)
                        {
                            // Getting the details of associate
                            var associate = _associateService.GetAssociate(stat.AssociateID);
                            string name = associate.DisplayFirstName.ToUpper() + " " + associate.DisplayLastName.ToUpper();
                            string mail = associate.EmailAddress.ToLower();
                            // Updating Custom Field 2 value
                            associate.Custom.Field2 = fieldValue;
                            _associateService.UpdateAssociate(associate);
                            associateID = associate.AssociateId;
                            // Adding a row to table
                            content = content + "<tr style='height:50px'><td style='border: 1px solid;'>" + rowCount + "</td><td style='border: 1px solid;'>" + name + "</td><td style='border: 1px solid;'>" + mail + "</td><td style='border: 1px solid;'>" + rank + "</td></tr>";
                            rowCount++;
                        }
                    }
                    // In this case, I am sending a mail for every 200 rows
                    if ((rowCount - 1) % 200 == 0 && content.Contains("<td"))
                    {
                        // Adding the last line of the table
                        content = content + "</tbody></table >";
                        // Task to send mail
                        async Task sendMaill()
                        {
                            // SendGrid API Key
                            var client = new SendGridClient("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");
                            // The email address which will send the mail
                            var from = new EmailAddress("no-reply@glowb.team", "Ruslan");
                            // The subject of mail
                            var subject = "Bigger Rank Notification API";
                            // The email address which will receive the mail
                            var to = new EmailAddress("system-internal@glowb.team", "Example User");
                            // I am not using this parameter
                            var plainTextContent = "";
                            // The content of mail
                            var htmlContent = content;
                            // Sendgrid function to send the mail
                            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
                            // The response of the function
                            var response = await client.SendEmailAsync(msg);
                        }
                        // Helper to run the task
                        AsyncHelper.RunSync(sendMaill);
                        // Table pattern
                        content = "<table style='width:100%;font-size: 18px;'><thead><tr><th style='border: 1px solid;'>#</th><th style='border: 1px solid;'>Full name</th><th style='border: 1px solid;'>E-mail</th>" +
                                    "<th style='border: 1px solid;'>Rank</th></tr></thead><tbody style='text-align: center;'>";
                    }
                }
                //In this case, I am sending the rest rows of the table
                if (content.Contains("<td"))
                {
                    // Adding the last line of the table
                    content = content + "</tbody></table >";
                    // Task to send mail
                    async Task sendMail()
                    {
                        // SendGrid API Key
                        var client = new SendGridClient("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");
                        // The email address which will send the mail
                        var from = new EmailAddress("no-reply@glowb.team", "Ruslan");
                        // The subject of mail
                        var subject = "Bigger Rank Notification API";
                        // The email address which will receive the mail
                        var to = new EmailAddress("system-internal@glowb.team", "Example User");
                        // I am not using this parameter
                        var plainTextContent = "";
                        // The content of mail
                        var htmlContent = content;
                        // Sendgrid function to send the mail
                        var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
                        // The response of the function
                        var response = await client.SendEmailAsync(msg);
                    }
                    // Helper to run the task
                    AsyncHelper.RunSync(sendMail);
                }
            }
            // In this case, exception occured
            catch (Exception e)
            {
                // I am showing the details of exception
                return new Ok(new { Status = 1, RequestMessage = associateID + "___" + e.ToString() });
            }
            // In this case, the operation completed successfully. It will show the row counts of the table in the result
            if(rowCount > 1)
            {
                return new Ok(new { Status = 1, RequestMessage = "The table should contain " + (rowCount - 1) + " row/s." });
            }
            else
            {
                return new Ok(new { Status = 1, RequestMessage = "No any news" });
            }
        }

    }
    // Class to list the CRM_Stats table
    public class Stat
    {
        public int recordnumber { get; set; }
        public DateTime last_modified { get; set; }
        public int AssociateID { get; set; }
        public int Rank { get; set; }
        public string PeriodKey { get; set; }
    }
    // Class to list the CRM_CommissionMerchantCommissionAssociateValues table
    public class CrmAV
    {
        public int AssociateID { get; set; }
        public int HighRank { get; set; }
    }
    // Class to list the CRM_CustomFields table
    public class CustomField
    {
        public int AssociateID { get; set; }
        public string Field2 { get; set; }
    }
}
