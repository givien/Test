using System;
using System.Collections.Generic;
using DirectScale.Disco.Extension;
using DirectScale.Disco.Extension.Services;
using System.Text;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace bombshells
{
    public class HyperWalletEUR : AccountCommissionMerchant
    {
        private readonly IAssociateService _associateService; // service is using to get detailed information about associates
        private readonly IMoneyOutService _moneyOutService; // using this service to edit CRM_CommissionMerchant_Active and CRM_CommissionMerchant_AssociateValues
        private readonly ILoggingService _loggingService; // service is using to add row to ExtensionLog table
        private const string ACCOUNT_NUMBER_KEY = "Token";
        public HyperWalletEUR(IAssociateService associateService, IMoneyOutService moneyOutService, ILoggingService loggingService) : base(
            new MerchantInfo(9003, "HyperWalletEUR", "EUR"),
            new List<CommissionMerchantCustomField>
            {
                new CommissionMerchantCustomField
                {
                    DisplayText = "Hyperwallet Token",
                    Key = ACCOUNT_NUMBER_KEY,
                    IsRequired = true
                }
            })
        {
            _associateService = associateService;
            _moneyOutService = moneyOutService;
            _loggingService = loggingService;
        }
        public override CommissionPaymentResults PayCommissions(int batchId, List<CommissionPayment> payments)// This method is triggered whenever you click on "Process Payments" button on Payment Approval page.
        {
            var results = new List<CommissionPaymentResult>(); // setting new results for the process
            foreach (var payment in payments)// setting a loop to process each payment in the batch
            {
                try// using try/catch method to debug exceptions
                {
                    if (_moneyOutService.GetCustomValues(payment.AssociateId).TryGetValue(ACCOUNT_NUMBER_KEY, out string accountNumber) && accountNumber.Length == 40)
                    // If an associate has account on HyperWallet, CRM_CommissionMerchant_AssociateValues would have her token value, so I'm trying to get it and if it's 40 charachters long I'm paying her, if not, calling ProvisionAccount function.
                    {
                        int AssociateId = payment.AssociateId; // getting associateId from the payment info
                        // Here I am checking payment amount to avoid losing 1 cent by user
                        var cents = (payment.Amount * 6 / 5) * 1000;
                        string amountt = "";
                        if(cents % 10 == 0)
                        {
                            amountt = (cents / 1000).ToString("0.##"); // converting and multiplying the amount to string for HyperWallet (DirectScale uses decimals)
                        }
                        else
                        {
                            amountt = (((cents - (cents % 10)) + 10) / 1000).ToString("0.##"); // converting and multiplying the amount to string for HyperWallet (DirectScale uses decimals)
                        }
                        PayInternal(amountt, AssociateId, accountNumber); // calling the API to pay them (accountNumber is a token)
                        void PayInternal(string amount, int associateId, string Token)
                        {
                            string clientPaymentId = $"{associateId}{DateTime.Now.Ticks}";
                            PaymentsEUR postData = new PaymentsEUR // Creating new API body
                            {
                                programToken = "prg-91aa4d85-9411-4579-91e4-b2efd937a416", // Program Token, provided by HyperWallet
                                purpose = "GP0002",// Purpose, check out this link for more info
                                destinationToken = Token, // Their Token, from CRM_CommissionMerchant_AssociateValues
                                clientPaymentId = clientPaymentId, // the unique number we got above
                                currency = "EUR", // Currency
                                amount = amount, // Amount
                                memo = associateId // memo, for future
                            };
                            string jsonString = JsonConvert.SerializeObject(postData); // Serializing the Json
                            var content = new StringContent(jsonString, Encoding.UTF8, "application/json");// content to post
                            string response = "";
                            async Task paymentRequest() // async task which makes a request for payment
                            {
                                HttpClient client = new HttpClient(); // creating request as HttpClient
                                string encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes("restapiuser@434468511689:PoYd8b9UJ6KV")); // encoding basic authorization credentials
                                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", encoded);// authorization of the request
                                client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json;"); // content type of the request
                                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json")); // accept type of the request
                                var result = await client.PostAsync("https://api.paylution.com/rest/v3/payments", content); //posting the API body
                                response = await result.Content.ReadAsStringAsync(); // getting the response of request
                            }
                            AsyncHelper.RunSync(paymentRequest); // using this helper to run asynchronous task as synchronous 
                            if (response.IndexOf("COMPLETED") > -1)// checking the status of request. If it is completed, we'll mark it as paid
                            {
                                results.Add(new CommissionPaymentResult() // adding new result to results list
                                {
                                    PaymentUniqueId = payment.PaymentUniqueId,
                                    TransactionNumber = payment.PaymentUniqueId,
                                    Status = CommissionPaymentStatus.Paid,
                                    DatePaid = DateTime.Now,
                                    CheckNumber = 100
                                });
                            }
                            else // in this case we'll mark it as failed
                            {
                                results.Add(new CommissionPaymentResult()
                                {
                                    PaymentUniqueId = payment.PaymentUniqueId,
                                    Status = CommissionPaymentStatus.Failed,
                                    ErrorMessage = $"The code ran correctly for {payment.AssociateId}, but HyperWallet's API response returned status: Failed. check their side for more info"
                                });
                                _loggingService.LogError(response);

                            }
                        }
                    }
                    else // in this case the associate does not have valid HyperwWallet token
                    {
                        ProvisionAccount(payment.AssociateId); // Call the ProvisionAccount function 
                        results.Add(new CommissionPaymentResult()// Marking it as Failed, so we will be able to reprocess it with only one click
                        {
                            PaymentUniqueId = payment.PaymentUniqueId,
                            Status = CommissionPaymentStatus.Failed,
                            ErrorMessage = $"If first time receiving this message, then account is created for {payment.AssociateId}, if more than once, then check CRM_CommissionMerchant_AssociateValues table."
                        });
                    }
                }
                catch (Exception e) // in case any other exception or error get the detailed info what's wrong
                {
                    results.Add(new CommissionPaymentResult()
                    {
                        PaymentUniqueId = payment.PaymentUniqueId,
                        Status = CommissionPaymentStatus.Failed,
                        ErrorMessage = $"Exception occurred while paying {payment.AssociateId} : {e.ToString()}"
                    });
                    _loggingService.LogError($"{e.Message.ToString()}"); // the detailed info about the exception will be in ExtensionLog table
                }
            }
            return new CommissionPaymentResults // Here I am setting the return value
            {
                Results = results
            };
        }
        public override CommissionMerchantAccountFields ProvisionAccount(int associateID) // This method gets called from above method in case an associate needs an account on HyperWallet.
        {
            #region Creating Users
            var associate = _associateService.GetAssociate(associateID);// Using DirectScale's service to gain more information about an assoicate
            int clientId = associate.AssociateId;// Gettin assoicate's ID
            string email = associate.EmailAddress; // Getting associate's email
            string firstName = associate.DisplayFirstName; // Getting associate's First Name
            string lastName = associate.DisplayLastName; // Getting associate's Last Name
            string country = associate.Address.CountryCode; // Getting associate's country
            NewUsersEUR postData = new NewUsersEUR
            {
                programToken = "prg-587dab65-e4de-43cf-8c6d-6e639d47d281",// Program Token, provided by HyperWallet
                profileType = "INDIVIDUAL",
                clientUserId = clientId,
                email = email,
                country = country,
                firstName = firstName,
                lastName = lastName
            };
            string jsonString = JsonConvert.SerializeObject(postData);// Serializing the Json
            var content = new StringContent(jsonString, Encoding.UTF8, "application/json");// the content to post
            string response = "";
            string userToken = "token";
            async Task accountRequest()// task which makes a request for creating account
            {
                HttpClient client = new HttpClient();// creating request as HttpClient
                string encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes("restapiuser@434468511689:PoYd8b9UJ6KV")); // encoding basic authorization credentials
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", encoded); // authorization of the request
                client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json;");// content type of the request
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));// accept type of the request
                var result = await client.PostAsync("https://api.paylution.com/rest/v3/users", content);//posting the NewUsersGBP Json
                response = await result.Content.ReadAsStringAsync();// getting the response of request
            }
            AsyncHelper.RunSync(accountRequest); // using this helper to run asynchronous task as synchronous 
            if (response.IndexOf("usr") > -1)
            {
                userToken = response.Substring(response.IndexOf("usr"), 40); // Getting account Token from the API response if exist
            }
            else
            {
                userToken = "invalid " + response.Split(',')[1].Split(':')[1]; // in this case process failed. So, I am trying to get details
            }
            #endregion
            #region editing the hook (CRM_CommissionMerhcant_AssociateValues)
            OnFileMerchant s = new OnFileMerchant // Updating CRM_CommissionMerchant_AssociateValues for the associate
            {
                MerchantId = 9003,
                AssociateId = clientId,
                MerchantName = "HyperWalletEUR",
                CustomValues = new Dictionary<string, string>
                {
                    { "Token",  userToken} // Updating their Token value
                }
            };
            _moneyOutService.SetActiveOnFileMerchant(s);
            return new CommissionMerchantAccountFields // This return is just a requirement, doesn't do anything
            {
                CustomValues = new Dictionary<string, string>
                {
                    { ACCOUNT_NUMBER_KEY, userToken }
                }
            };
            #endregion
        }
    }
    public class PaymentsEUR
    {
        public string programToken { get; set; }
        public string purpose { get; set; }
        public string destinationToken { get; set; }
        public string clientPaymentId { get; set; }
        public string currency { get; set; }
        public string amount { get; set; }
        public int memo { get; set; }
    }
    public class NewUsersEUR
    {
        public string programToken { get; set; }
        public string profileType { get; set; }
        public int clientUserId { get; set; }
        public string email { get; set; }
        public string country { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
    }
}
