using System;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using bombshells;
using Dapper;
using DirectScale.Disco.Extension.Api;
using DirectScale.Disco.Extension.Services;
using SendGrid;
using SendGrid.Helpers.Mail;

public class MessageToMentorAPI : IApiEndpoint
{
    private readonly IDataService _dataService;
    private readonly IAssociateService _associateService;
    public MessageToMentorAPI(IAssociateService associateService, IDataService dataService)
    {
        _dataService = dataService;
        _associateService = associateService;
    }
    public ApiDefinition GetDefinition()
    {
        return new ApiDefinition
        {
            Route = "bombshells/MessageToMentorAPI",
            RequireAuthentication = false
        };
    }
    public IApiResponse Post(ApiRequest request)
    {
        using (var db = new SqlConnection(_dataService.ConnectionString.ConnectionString))
        {
            try
            {
                string userID = "";
                request.QueryParams.TryGetValue("QueryParams", out userID);
                string MentorQuery = $"SELECT UplineID FROM dbo.CRM_UnilevelTree WHERE DistributorID = " + userID + " ; ";
                var MentorList = db.Query<UnilevelTree>(MentorQuery).ToList();
                if (MentorList.Count < 1)
                {
                    return new Ok(new { Status = 1, RequestMessage = "Mentor not found" });
                }
                string SenderQuery = $"SELECT FirstName, LastName FROM dbo.CRM_Distributors WHERE recordnumber = " + userID + " ; ";
                var SenderList = db.Query<Distributor>(SenderQuery).ToList();
                if (SenderList.Count < 1)
                {
                    return new Ok(new { Status = 1, RequestMessage = "Sender not found" });
                }
                var sender = SenderList[0];
                var receiver = _associateService.GetAssociate(MentorList[0].UplineID);
                
                async Task sendMail()
                {
                    // SendGrid API Key
                    var client = new SendGridClient("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");
                    // The email address which will send the mail
                    var from = new EmailAddress("no-reply@glowb.team", sender.FirstName + " " + sender.LastName);
                    // The subject of mail
                    var subject = "Glowb Messenger";
                    // The email address which will receive the mail
                    var to = new EmailAddress(receiver.EmailAddress, receiver.DisplayFirstName + " " + receiver.DisplayLastName);
                    // I am not using this parameter
                    var plainTextContent = "";
                    // The content of mail
                    var htmlContent = request.Headers["Message"];
                    // Sendgrid function to send the mail
                    var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
                    // The response of the function
                    var response = await client.SendEmailAsync(msg);
                }
                // Helper to run the task
                AsyncHelper.RunSync(sendMail);
            }
            catch (Exception e)
            {
                return new Ok(new { Status = 4, RequestMessage = e.Message });
            }
            
            return new Ok(new { Status = 1, RequestMessage = "Message Sent" });
        }

    }
    public class UnilevelTree
    {
        public int UplineID { get; set; }
    }
    public class Distributor
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
