using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using DirectScale.Disco.Extension;
using DirectScale.Disco.Extension.Api;
using DirectScale.Disco.Extension.Services;

public class CurrencyAPI : IApiEndpoint
{
    public IMoneyOutService _moneyOutService; // using this service to edit CRM_CommissionMerchant_Active and CRM_CommissionMerchant_AssociateValues
    private readonly IDataService _dataService;
    private readonly IAssociateService _associateService;
    public CurrencyAPI(IAssociateService associateService, IMoneyOutService moneyOutService, IDataService dataService)
    {
        _moneyOutService = moneyOutService; // Service setup
        _dataService = dataService;
        _associateService = associateService;
    }
    public ApiDefinition GetDefinition()
    {
        return new ApiDefinition
        {
            Route = "bombshells/CurrencyAPI",
            RequireAuthentication = false
        };
    }
    public IApiResponse Post(ApiRequest request)
    {
        using (var db = new SqlConnection(_dataService.ConnectionString.ConnectionString))
        {
            int associateId = 0;
            try
            {
                string x = "";
                request.QueryParams.TryGetValue("QueryParams", out x);
                string distributorsQuery = $"SELECT recordnumber FROM CRM_Distributors where recordnumber >= " + x;
                var distributorsList = db.Query<Distributor>(distributorsQuery).ToList();
                if (distributorsList.Count < 1)
                {
                    return new Ok(new { Status = 1, RequestMessage = "There is not any useful row in CRM_Distributors" });
                }
                foreach (var user in distributorsList)
                {
                    var associate = _associateService.GetAssociate(user.recordnumber);
                    associateId = associate.AssociateId;
                    if (associate.ShipAddress.CountryCode == "GB")
                    {
                        OnFileMerchant s = new OnFileMerchant // I have to configure data into CRM_CommissionMerchant_AssociateValues, even though I only want to add CRM_CommissionMerchant_Active
                        {
                            MerchantId = 9001,
                            AssociateId = associateId,
                            MerchantName = "HyperWalletGBP",
                            CustomValues = new Dictionary<string, string>
                    {
                        { "Token", "NoAccount" } // So, I'm setting their Token values to "NoAccount"
                    }
                        };
                        _moneyOutService.SetActiveOnFileMerchant(s); // Updating the SQL with new values (only inserting in this case)
                    }
                    else if (associate.ShipAddress.CountryCode == "AU")
                    {
                        OnFileMerchant s = new OnFileMerchant
                        {
                            MerchantId = 9002,
                            AssociateId = associateId,
                            MerchantName = "HyperWalletAUD",
                            CustomValues = new Dictionary<string, string>
                    {
                        { "Token", "NoAccount" }
                    }
                        };
                        _moneyOutService.SetActiveOnFileMerchant(s);
                    }
                    else
                    {
                        OnFileMerchant s = new OnFileMerchant
                        {
                            MerchantId = 9003,
                            AssociateId = associateId,
                            MerchantName = "HyperWalletEUR",
                            CustomValues = new Dictionary<string, string>
                    {
                        { "Token", "NoAccount" }
                    }
                        };
                        _moneyOutService.SetActiveOnFileMerchant(s);
                    }
                }
            }
            catch (Exception e)
            {
                return new Ok(new { Status = 1, RequestMessage = associateId + "__" + e.ToString() });
            }
            return new Ok(new { Status = 1, RequestMessage = "Completed. - " + associateId });
        }

    }
    public class Distributor
    {
        public int recordnumber { get; set; }
    }
}
