//using Dapper;
//using System.Data.SqlClient;
//using DirectScale.Disco.Extension.Api;
//using DirectScale.Disco.Extension.Services;
//using System.Linq;
//using System.Threading.Tasks;
//using SendGrid;
//using SendGrid.Helpers.Mail;
//using System;
//using DirectScale.Disco.Extension.Hooks;
//using DirectScale.Disco.Extension.Hooks.Associates.Enrollment;

//namespace bombshells.Hooks
//{
//    public class TestingDSSQLData : IHook<WriteApplicationHookRequest, WriteApplicationHookResponse>
//    {
//        private readonly IDataService _dataService;
//        public IMoneyOutService _moneyOutService;
//        public TestingDSSQLData(IMoneyOutService moneyOutService, IDataService dataService)
//        {
//            _dataService = dataService;
//            _moneyOutService = moneyOutService;
//        }
//        public WriteApplicationHookResponse Invoke(WriteApplicationHookRequest request, Func<WriteApplicationHookRequest, WriteApplicationHookResponse> func)
//        {
//            var responsee = func(request);
//            GetTheData(208);
//            void GetTheData(int associateId)
//            {
//                try
//                {
//                    //   {"Status": 1,"Request Message":[ {"HighRank ": 120}]}
//                    var dbConnection = new SqlConnection(_dataService.ConnectionString.ConnectionString);
//                    string sql = $"select HighRank from CRM_CommissionAssociateValues where ComPeriodID = month(GETDATE()) + 18 and AssociateID = {associateId}";
//                    var response = new Ok(new { Status = 1, RequestMessage = dbConnection.Query<Data>(sql).ToList() });
//                    int len = Convert.ToInt32(response.Content.Length);
//                    string content = System.Text.Encoding.UTF8.GetString(response.Content);
//                    if (len == 48)
//                    {
//                        int HighestRank = Convert.ToInt32(content.Substring(43, 3));
//                    }
//                    else if (len == 47)
//                    {
//                        int HighestRank = Convert.ToInt32(content.Substring(43, 2));
//                    }
//                    else
//                    {
//                        int HighestRank = Convert.ToInt32(content.Substring(43, 1));
//                    }
//                    string email = "lukamusashvili@gmail.com";
//                    Email1(email, content).Wait();
//                }
//                catch (Exception e)
//                {
//                    string email = "lukamusashvili@gmail.com";
//                    string resp = e.Message;
//                    Email1(email, resp).Wait();
//                }
//            }
//            async Task Email1(string email, string resp)
//            {
//                var client = new SendGridClient("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"); // API key
//                var from = new EmailAddress("lukam1.pod@gmail.com", "Luka"); // From
//                var subject = "Sending with SendGrid is Fun"; // Email Subject
//                var to = new EmailAddress(email); // To
//                var plainTextContent = ""; // Don't touch it
//                var htmlContent = "The Highest Rank ever for Faye currently is " + resp; // Email Body
//                var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent); // Don't touch it
//                var response = await client.SendEmailAsync(msg); // Don't touch it
//            }
//            return responsee;
//        }
//        public class Data
//        {
//            public int HighRank { get; set; }
//        }
//    }
//}
