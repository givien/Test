using System;
using DirectScale.Disco.Extension.Hooks;
using DirectScale.Disco.Extension.Hooks.Associates.Enrollment;
using DirectScale.Disco.Extension;
using System.Collections.Generic;
using DirectScale.Disco.Extension.Services;
using Microsoft.Extensions.Logging;

namespace bombshells.Hooks
{
    public class HyperWalletHook : IHook<WriteApplicationHookRequest, WriteApplicationHookResponse> // Hook registration
    {
        public IMoneyOutService _moneyOutService; // using this service to edit CRM_CommissionMerchant_Active and CRM_CommissionMerchant_AssociateValues
        private readonly IAssociateService _associateService;
        private readonly ILoggingService _loggingService;
        public HyperWalletHook(IAssociateService associateService, IMoneyOutService moneyOutService, ILoggingService loggingService)
        {
            _moneyOutService = moneyOutService; // Service setup
            _associateService = associateService;
            _loggingService = loggingService;
        }
        public WriteApplicationHookResponse Invoke(WriteApplicationHookRequest request, Func<WriteApplicationHookRequest, WriteApplicationHookResponse> func) // This hook gets triggered whenever new associate signs up to our system.
        {
            var response = func(request); // Getting Hook's response
            int associateId = response.ApplicationResponse.AssociateId; // Using the hook's response to get associateId
            try
            {
                var associate = _associateService.GetAssociate(associateId);
                associate.Custom.Field1 = "Validated";
                _associateService.UpdateAssociate(associate);
            }
            catch(Exception e)
            {
                _loggingService.LogError($"{e.ToString()}");

            }
            if (request.Application.ShippingAddress.CountryCode == "GB")
            {
                OnFileMerchant s = new OnFileMerchant // I have to configure data into CRM_CommissionMerchant_AssociateValues, even though I only want to add CRM_CommissionMerchant_Active
                {
                    MerchantId = 9001,
                    AssociateId = associateId,
                    MerchantName = "HyperWalletGBP",
                    CustomValues = new Dictionary<string, string>
                    {
                        { "Token", "NoAccount" } // So, I'm setting their Token values to "NoAccount"
                    }
                };
                _moneyOutService.SetActiveOnFileMerchant(s); // Updating the SQL with new values (only inserting in this case)
            }
            else if (request.Application.ShippingAddress.CountryCode == "AU")
            {
                OnFileMerchant s = new OnFileMerchant
                {
                    MerchantId = 9002,
                    AssociateId = associateId,
                    MerchantName = "HyperWalletAUD",
                    CustomValues = new Dictionary<string, string>
                    {
                        { "Token", "NoAccount" }
                    }
                };
                _moneyOutService.SetActiveOnFileMerchant(s);
            }
            else
            {
                OnFileMerchant s = new OnFileMerchant
                {
                    MerchantId = 9003,
                    AssociateId = associateId,
                    MerchantName = "HyperWalletEUR",
                    CustomValues = new Dictionary<string, string>
                    {
                        { "Token", "NoAccount" }
                    }
                };
                _moneyOutService.SetActiveOnFileMerchant(s);
            }
            return response;
        }
    }
}
