using System;
using DirectScale.Disco.Extension.Hooks;
using DirectScale.Disco.Extension.Hooks.Associates.Enrollment;
using DirectScale.Disco.Extension.Services;
using Microsoft.Extensions.Logging;
using System.Net;
using System.IO;

namespace bombshells.Hooks
{
    public class KlaviyoHook : IHook<WriteApplicationHookRequest, WriteApplicationHookResponse> // Hook registration
    {
        private readonly IAssociateService _associateService; // service is using to get detailed information about associates
        private readonly ILoggingService _loggingService; // service is using to add row to ExtensionLog table
        public KlaviyoHook(IAssociateService associateService, IMoneyOutService moneyOutService, ILoggingService loggingService)
        {
            _associateService = associateService;
            _loggingService = loggingService;
        }
        public WriteApplicationHookResponse Invoke(WriteApplicationHookRequest request, Func<WriteApplicationHookRequest, WriteApplicationHookResponse> func) // This hook gets triggered whenever new associate signs up to our system.
        {
            var response = func(request); // Getting Hook's response
            int associateId = response.ApplicationResponse.AssociateId; // Using the hook's response to get associateId
            var associate = _associateService.GetAssociate(associateId); // Finding the Associate which just registered
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("https://a.klaviyo.com/api/v2/list/T6ii5v/members?api_key=pk_20d86aa2f2233555a10c88e2a41038767c"); // Request's URL which will add the Associate's e-mail to Klaviyo
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Accept = "application/json";
            httpWebRequest.Method = "POST";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = "{\"profiles\":[{\"email\":\"" + associate.EmailAddress + "\"}]}";

                streamWriter.Write(json);
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
//                if (!result.ToString().Contains("email")) // In this case something went wrong and I am adding new row to Extension Log table with detailed result
//                {
                    _loggingService.LogError($"{result}");
//                }
            }
            return response;
        }
    }
}
