﻿//using System.Data.SqlClient;
//using DirectScale.Disco.Extension.Api;
//using DirectScale.Disco.Extension.Services;
//using System.Linq;
//using System;
//using Dapper;
//using System.Text;
//using DirectScale.Disco.Extension.Hooks.Commissions;
//using DirectScale.Disco.Extension.Hooks;
//using System.Threading.Tasks;
//using SendGrid;
//using SendGrid.Helpers.Mail;

//public static class TooComplicatedButThisIsTheOnlyWay
//{
//    public class SendGridHook2 : IHook<LogRealtimeRankAdvanceHookRequest, LogRealtimeRankAdvanceHookResponse> // This hook is triggered when an ambassador gets a new sale
//    {
//        private readonly IAssociateService _associateService;
//        private readonly IDataService _dataService;
//        public SendGridHook2(IAssociateService associateService, IDataService dataService)
//        {
//            _associateService = associateService;
//            _dataService = dataService;
//        }
//        public LogRealtimeRankAdvanceHookResponse Invoke(LogRealtimeRankAdvanceHookRequest request, Func<LogRealtimeRankAdvanceHookRequest, LogRealtimeRankAdvanceHookResponse> func)
//        {
//            int associateId = request.AssociateId;
//            #region The Highest Rank For Her
//            var dbConnection = new SqlConnection(_dataService.ConnectionString.ConnectionString);
//            string sql = $"select HighRank from CRM_CommissionAssociateValues where ComPeriodID = month(GETDATE()) + 18 and AssociateID = {associateId}";
//            var response = new Ok(new { Status = 1, RequestMessage = dbConnection.Query<Data>(sql).ToList() });
//            int len = Convert.ToInt32(response.Content.Length);
//            int HighestRank = 0;
//            string content = Encoding.UTF8.GetString(response.Content);
//            if (len == 48)
//            {
//                HighestRank = Convert.ToInt32(content.Substring(43, 3));
//            }
//            else if (len == 47)
//            {
//                HighestRank = Convert.ToInt32(content.Substring(43, 2));
//            }
//            else
//            {
//                HighestRank = Convert.ToInt32(content.Substring(43, 1));
//            }
//            #endregion
//            int newRank = request.NewRank;
//            var associate = _associateService.GetAssociate(associateId);
//            string email = "lukamusashvili@gmail.com"; //associate.EmailAddress; after testing
//            #region Comparing new with the Highest
//            if (newRank > HighestRank)
//            {
//                Email1(email, content).Wait();
//            }
//            else
//            {
//                Email2(email, content).Wait();
//            }
//            #endregion
//            return func(request);
//        }
//    }
//    static async Task Email1(string email, string content) // If the new rank is the highest ever
//    {
//        var client = new SendGridClient("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"); // API key
//        var from = new EmailAddress("lukam1.pod@gmail.com", "Luka"); // From
//        var subject = "Sending with SendGrid is Fun"; // Email Subject
//        var to = new EmailAddress(email); // To
//        var plainTextContent = ""; // Don't touch it
//        var htmlContent = $"New Record Rank! {content}"; // Email Body
//        var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent); // Don't touch it
//        var response = await client.SendEmailAsync(msg); // Don't touch it
//    }
//    static async Task Email2(string email, string content) // If she had higher or equal rank before
//    {
//        var client = new SendGridClient("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"); // API key
//        var from = new EmailAddress("lukam1.pod@gmail.com", "Luka"); // From
//        var subject = "New Rank"; // Email Subject
//        var to = new EmailAddress(email); // To
//        var plainTextContent = ""; // Don't touch it
//        var htmlContent = $"Not The Highest {content}"; // Email Body
//        var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent); // Don't touch it
//        var response = await client.SendEmailAsync(msg); // Don't touch it
//    }
//    public class Data
//    {
//        public int HighRank { get; set; }
//    }
//}