﻿//using System;
//using DirectScale.Disco.Extension.Hooks;
//using DirectScale.Disco.Extension.Hooks.Associates.Enrollment;
//using DirectScale.Disco.Extension.Services;
//using System.Timers;
//using System.Threading.Tasks;
//using SendGrid;
//using SendGrid.Helpers.Mail;

//namespace bombshells.Hooks
//{
//    public class TestingDailyRun : IHook<WriteApplicationHookRequest, WriteApplicationHookResponse>
//    {
//        public IMoneyOutService _moneyOutService;
//        public TestingDailyRun(IMoneyOutService moneyOutService)
//        {
//            _moneyOutService = moneyOutService;
//        }
//        public WriteApplicationHookResponse Invoke(WriteApplicationHookRequest request, Func<WriteApplicationHookRequest, WriteApplicationHookResponse> func)
//        {
//            var response = func(request);
//            int associateId = response.ApplicationResponse.AssociateId;
//            string associateEmail = "lukamusashvili@gmail.com";
//            int counter = 0;
//            #region Interval
//            Timer myTimer = new Timer();
//            myTimer.Elapsed += new ElapsedEventHandler(OnTimer);
//            myTimer.Interval = 3000; // 24 hours is 86400000
//            myTimer.Start();
//            void OnTimer(Object source, ElapsedEventArgs e)
//            {
//                counter += 1;
//                if (counter == 3)
//                {
//                    myTimer.Stop();
//                    Execute(associateEmail, counter, associateId).Wait();
//                }
//                else
//                {
//                    Execute(associateEmail, counter, associateId).Wait();
//                }
//            }
//            #endregion
//            async Task Execute(string email, int counterr, int associate)
//            {
//                var client = new SendGridClient("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"); // API key
//                var from = new EmailAddress("lukam1.pod@gmail.com", "Luka"); // From
//                var subject = "Sending with SendGrid is Fun"; // Email Subject
//                var to = new EmailAddress(email); // To
//                var plainTextContent = ""; // Don't touch it
//                var htmlContent = $"<strong>{counterr}, {associateId}</strong>"; // Email Body
//                var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent); // Don't touch it
//                var responsee = await client.SendEmailAsync(msg); // Don't touch it
//            }
//            return response;
//        }
//    }
//}
