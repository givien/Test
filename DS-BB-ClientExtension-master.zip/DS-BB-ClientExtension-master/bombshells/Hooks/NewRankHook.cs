﻿using System;
using DirectScale.Disco.Extension.Hooks;
using DirectScale.Disco.Extension.Services;
using System.Threading.Tasks;
using SendGrid;
using SendGrid.Helpers.Mail;
using DirectScale.Disco.Extension.Hooks.Associates;

namespace bombshells.Hooks
{
    public class NewRankHook : IHook<GetAssociatesStatsHookRequest, GetAssociatesStatsHookResponse>
    {
        private readonly IDataService _dataService;
        public NewRankHook(IDataService dataService)
        {
            _dataService = dataService;
        }
        public GetAssociatesStatsHookResponse Invoke(GetAssociatesStatsHookRequest request, Func<GetAssociatesStatsHookRequest, GetAssociatesStatsHookResponse> func)
        {
            var response = func(request);
            int[] array = (int[])request.AssociateIds;
            foreach (int assId in array)
            {
                string associateEmail = "lukamusashvili@gmail.com";
                Execute(associateEmail, assId).Wait();
            }
            async Task Execute(string email, int associateId)
            {
                var client = new SendGridClient("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"); // API key
                var from = new EmailAddress("lukam1.pod@gmail.com", "Luka"); // From
                var subject = "Sending with SendGrid is Fun"; // Email Subject
                var to = new EmailAddress(email); // To
                var plainTextContent = ""; // Don't touch it
                var htmlContent = $"<strong>There were some changes for associate N{associateId}"; // Email Body
                var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent); // Don't touch it
                var responsee = await client.SendEmailAsync(msg); // Don't touch it
            }
            return response;
        }
    }
}
