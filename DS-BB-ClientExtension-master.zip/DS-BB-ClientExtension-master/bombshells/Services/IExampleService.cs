
//namespace bombshells.Services
//{
//    public interface IExampleService
//    {
//        string GetValue();
//        bool IsValidEmail(string email);
//    }
//}
